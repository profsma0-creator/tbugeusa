# Advanced Neurobiology of Trauma — publication readiness status

**Integrated review proof 04 · 21 October 2026 · RELEASE HOLD**

## What this artefact is

`Advanced_Neurobiology_of_Trauma_Integrated_Review_Proof_04.pdf` is the first assembly in which **all twenty chapters are newly written text** rather than source-page facsimiles. It has **268 physical pages: seven Roman front-matter pages and 261 Arabic-numbered main-matter pages**, uniform 7 × 10 inch trim, no blank pages, 31 bookmarks, and generated contents whose locators were verified against the assembled file.

Replacing facsimiles with written chapters necessarily reduced the extent of the book. The source ran to 1,722 pages, but most of that length consisted of repeated template passages, duplicated front matter and production notes. The reconstructed chapters are concise treatments, not equivalent-length replacements of roughly eighty source pages each. That is the principal remaining editorial question, and it is set out below.

## Chapter map

| Ch. | First folio | Pages | Words | Cited references |
|---|---|---|---|---|
| 1 | 1 | 23 | — | 7 |
| 2 | 24 | 30 | — | 17 |
| 3 | 54 | 12 | 2,609 | 5 |
| 4 | 66 | 11 | 2,282 | 3 |
| 5 | 77 | 10 | 2,094 | 4 |
| 6 | 87 | 11 | 2,159 | 3 |
| 7 | 98 | 10 | 1,990 | 4 |
| 8 | 108 | 10 | 1,982 | 4 |
| 9 | 118 | 10 | 1,882 | 2 |
| 10 | 128 | 9 | 1,807 | 6 |
| 11 | 137 | 9 | 1,511 | 3 |
| 12 | 146 | 9 | 1,621 | 1 |
| 13 | 155 | 9 | 1,481 | 5 |
| 14 | 164 | 9 | 1,519 | 1 |
| 15 | 173 | 9 | 1,665 | 4 |
| 16 | 182 | 8 | 1,482 | 1 |
| 17 | 190 | 8 | 1,399 | 3 |
| 18 | 198 | 8 | 1,269 | 2 |
| 19 | 206 | 8 | 1,293 | 2 |
| 20 | 214 | 8 | 1,217 | 1 |

Back matter begins at Arabic page 222: glossary 222–240, acronyms 241, appendices 242–243, research resources 244, laboratory teaching protocols 245, learner worksheets 246–254, professional standards 255, further reading 256, comprehensive source references 257–261.

## Work completed for proof 04

1. **Chapters 3–20 written from verified sources.** Each chapter has ten numbered sections, learning objectives, a cautionary note, a synthesis table, a composite teaching case explicitly marked non-clinical, six review questions, three research assignments, a summary and a reference list. Chapters 3–20 total 31,262 words.
2. **Reference apparatus.** A 39-entry reference pool of APA 7 records underlies the new chapters. Twenty-seven new in-text citations were inserted so that no chapter is unsourced; chapters 3–20 now cite between one and six verified records each.
3. **Typesetting.** Every chapter was typeset twice so that the cached chapter contents resolve to the correct pages. Tables now size their columns from measured word widths and reduce type size when necessary, eliminating mid-word breaks such as "Glutam/ate". The integrated proof carries one consistent running head instead of the per-chapter "developmental proof" heads.
4. **Front matter rewritten** to describe the actual twenty-chapter sequence and to state the reconstruction status accurately.
5. **Verification.** `scripts/check_integrated_proof.py` passes all assertions: page count against map, trim, corporate-author metadata, copyright notice, absence of the unconfirmed 3.09 credit value, no bracket placeholders, no "programmeme", Roman/Arabic labels, twenty chapter bookmarks pointing to mapped folios, nine worksheets preserving 76 completion fields, absence of the generic glossary formula, and survival of all 187 glossary headwords and definitions.

## Verification status of sources

DOIs, volumes, pages and identifiers were checked against publisher or PubMed records for the majority of the pool, including Shonkoff & Garner 2012; Teicher & Samson 2016; Felitti et al. 1998; Yehuda et al. 2015; Etkin & Wager 2007; Lanius et al. 2010; Herman et al. 2016; Ulrich-Lai & Herman 2009; McEwen 1998; Lupien et al. 2009; Milad & Quirk 2012; Nader et al. 2000; Ochsner & Gross 2005; LeDoux 2000; Fenster et al. 2018; Arnsten 2009; Shackman et al. 2011; Craig 2009; Menon 2011; Stoodley & Schmahmann 2009; Godoy et al. 2018; Goldstein & Kopin 2007; Scoville & Milner 1957; Pitman et al. 2012; Hinojosa et al. 2024; Germain 2013; Hori & Kim 2019; Ehlers & Clark 2000; Craske et al. 2014; Page et al. 2021; Kessler et al. 1995.

**Still to confirm before a final register:** the Maren 2001 and Squire 2004 records, and the exact access dates and page titles of the five agency pages (NHGRI glossary, NHGRI epigenomics fact sheet, FDA biomarker page, NCTSN complex trauma page, NIMH PTSD page). No reference in this proof was invented, and no DOI was guessed: where a detail could not be confirmed, the record was not used.

## Release blockers

1. **Chapter depth.** Eighteen chapters of 1,217–2,609 words are sound concise treatments but are shorter than a doctoral textbook chapter would normally be, and much shorter than the source chapters they replace. Either the chapters must be expanded toward the originally agreed 3,500–4,500 words, or the concise format must be explicitly accepted as the edition's design. This decision changes roughly 30,000 words of text and should be taken before further polishing.
2. **Glossary.** All 182 generic definitions were replaced, but **128 of 187 entries still await term-specific source checks**, and none has been reconciled with the usage of the new chapters.
3. **Retained back matter.** Acronyms, appendices, research resources, laboratory protocols, professional standards, further reading and the comprehensive source references remain source facsimiles. They carry the original typography and unverified content, and the source reference list may conflict with the new chapter bibliographies.
4. **Reference audit.** Five records and five agency pages remain unchecked (above); the chapter-level citation-to-claim audit has not been done by a subject specialist.
5. **Independent proofreading.** No second, independent whole-book proofreading pass has been completed. The automated checks cover mechanical properties, not scholarly accuracy or prose quality.
6. **Figures and index.** The book contains two conceptual diagrams per chapter (levels of analysis; evidence appraisal) but no chapter-specific data figures; there is no index. Neither should be fabricated, but the absence should be a conscious decision.

**Release decision: HOLD.** The file is labelled NOT FINAL on every page and in its metadata. It is a genuine twenty-chapter review draft, not a publication-ready edition.

## Files

- `Advanced_Neurobiology_of_Trauma_Integrated_Review_Proof_04.pdf` — current complete-book assembly.
- `page-map.json` — component-to-book page mapping for this assembly.
- `quality-checks.json` — automated check results and uncompleted release criteria.
- `Learner_Worksheets.pdf`, `Front_Matter_Review_Proof.pdf`, `Contents_Review_Proof.pdf` — component proofs.
- `Author_Decisions.json` — confirmed author decisions.
- Chapter proofs, editable manuscripts and chapter reference lists: `deliverables/chapter01/` … `deliverables/chapter20/`, `manuscript/`.
