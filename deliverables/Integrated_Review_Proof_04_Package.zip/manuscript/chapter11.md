# Chapter 11

## Emotion Regulation, Interoception, and Dissociation

**Central question.** How do people manage intense emotion, how do they sense their own bodies, and what happens when these processes become disrupted?

### Learning objectives

- distinguish emotion generation from emotion regulation;
- describe major regulatory strategies and their neural correlates;
- explain interoception and its measurement;
- distinguish depersonalisation from derealisation;
- evaluate the assessment of dissociative phenomena.

## Introduction

Emotion regulation is the set of processes by which people influence which emotions they have, when they have them, and how they express them. It is not the suppression of feeling; it is the modulation of feeling in the service of goals. Interoception is the sense of the internal state of the body. Dissociation is a disruption of the normally integrated functions of consciousness, memory, identity, body awareness and perception.

These three topics belong together because trauma often disrupts all of them. A survivor may be flooded by emotion, cut off from bodily sensation, or feel detached from themselves and their surroundings. Understanding the mechanisms helps clinicians respond precisely rather than offering generic reassurance.

> **A note on "regulation".** Regulation is not the same as control. Trying to suppress an emotion often increases it. Effective regulation includes accepting emotion, changing its trajectory, and choosing behaviour that is consistent with one's values.

## 11.1 Emotion generation

Emotion generation involves appraisal of a stimulus, physiological response, action tendency and subjective feeling. The classic debate between basic-emotion and constructivist accounts continues: are emotions discrete entities with dedicated circuits, or constructed from more general processes of interoception, memory and categorisation?

For trauma, the practical point is that emotion is not a single event but a process with multiple entry points. A person can intervene at the level of attention, appraisal, bodily state or behaviour. Different interventions target different points.

The amygdala, insula, prefrontal cortex and brainstem all participate in emotion generation. The amygdala is involved in detecting salient and threat-related stimuli; the insula in representing bodily states; the prefrontal cortex in appraisal and regulation. No single region generates an emotion.

## 11.2 Regulatory strategies

Gross's process model distinguishes antecedent-focused strategies, which act before the emotion is fully generated, from response-focused strategies, which act after. Reappraisal is antecedent-focused: it changes the meaning of a situation. Suppression is response-focused: it inhibits emotional expression.

Reappraisal is generally associated with better outcomes than suppression, though the distinction is not absolute and depends on context. Other strategies include acceptance, problem-solving, distraction, social support and situation selection.

People with PTSD often rely on avoidance and suppression, which reduce distress in the short term but maintain it in the long term. Therapy aims to broaden the repertoire rather than to prescribe a single strategy.

## 11.3 Cognitive reappraisal

Reappraisal involves changing the interpretation of an event to change its emotional impact. It depends on prefrontal and cingulate control systems interacting with emotion-generative regions (Ochsner & Gross, 2005).

Reappraisal is effective for many people, but it is not universally helpful. It can be difficult under high arousal, and it can be experienced as invalidating if offered too early. In trauma treatment, reappraisal is usually introduced after safety and stabilisation, and it is distinguished from premature "reframing" that asks the person to minimise what happened.

Cultural context matters. Some reappraisal strategies emphasise acceptance, community or spiritual meaning; others emphasise individual control. Clinicians should ask what is meaningful to the person rather than assuming a single model.

## 11.4 Attention and inhibition

Attention is the gateway to emotion regulation. Selective attention to threat maintains anxiety; attentional avoidance prevents corrective learning. Both patterns occur in trauma.

Inhibitory control—the capacity to suppress a prepotent response—is supported by prefrontal circuits and is impaired under stress. This is why people make impulsive decisions when highly aroused and why "just stop" is not a useful instruction.

Attention training and mindfulness-based approaches aim to improve attentional control. Evidence is mixed; mindfulness can be helpful for some and can be distressing for others, particularly when interoceptive exposure is introduced too quickly.

## 11.5 Interoceptive processing

Interoception includes the detection of internal signals, the interpretation of those signals, and the beliefs about one's sensitivity. These components are related but distinct, and they are measured differently.

The insula is central to interoceptive representation. Craig (2009) proposed a posterior-to-anterior progression from primary representation to integrated awareness. This model is influential but its stronger claims remain debated.

Interoceptive accuracy is often measured with heartbeat detection tasks. Performance varies widely, and the relationship between accuracy, anxiety and trauma is inconsistent. Some studies report reduced accuracy in PTSD, others report no difference or increased sensitivity.

## 11.6 Body awareness

Body awareness is the subjective sense of one's body, including posture, movement, tension and sensation. It can be heightened, diminished or distorted.

Trauma can produce both hyperawareness—scanning for signs of danger in the body—and numbing. Somatic symptoms are common, and they are real: they involve physiological changes, not imagined ones. Assessment should include medical review where indicated.

Body-oriented therapies use awareness, movement and breathing to improve regulation. Evidence for specific approaches is limited, but the general principle—that helping people tolerate and interpret bodily sensations can reduce avoidance—is reasonable.

## 11.7 Depersonalisation

Depersonalisation is a feeling of detachment from oneself: one's thoughts, feelings, body or actions feel unreal, as if one is an outside observer. It is common in trauma, particularly in the immediate aftermath, and it can be persistent.

Neuroimaging studies of depersonalisation report altered activity in insular, prefrontal and limbic regions, but findings are inconsistent. The experience is subjective and difficult to capture in a scanner.

Clinically, depersonalisation should be distinguished from psychosis: the person retains reality testing—they know the experience is strange, not that it is literally true. It should also be distinguished from absence seizures and other neurological conditions.

## 11.8 Derealisation

Derealisation is a feeling that the external world is unreal, distant, dreamlike or visually distorted. It often co-occurs with depersonalisation but is conceptually distinct: depersonalisation concerns the self, derealisation the surroundings.

Both are listed in DSM-5 as dissociative symptoms and as part of the dissociative subtype of PTSD. Their presence suggests a different regulatory configuration, with overmodulation rather than undermodulation of affect (Lanius et al., 2010).

Assessment should ask specifically about these experiences, because people may not volunteer them and may not have language for them.

## 11.9 State-dependent responding

Dissociative states can be state-dependent: memory, affect and behaviour differ depending on which state the person is in. A person may recall an event in one state and be unable to access it in another.

State-dependent learning is not fully understood, and the concept has been overused to explain complex clinical phenomena. It is nonetheless useful for understanding why a patient may seem inconsistent across sessions and why continuity of care matters.

## 11.10 Assessment of dissociative phenomena

Assessment should be structured and gentle. Instruments include the Dissociative Experiences Scale and the Clinician-Administered Dissociative States Scale. These are screening tools, not diagnoses.

Assessment should distinguish dissociation from absorption, daydreaming, fatigue and substance effects. It should also consider cultural context: experiences interpreted as spiritual or trance-like may not be pathological.

The clinical response should be proportionate. Mild dissociation may need psychoeducation and grounding; severe dissociation may require staged trauma treatment with attention to stabilisation before processing.

## Synthesis

Table 11.1 summarises regulatory and dissociative phenomena.

Table 11.1. Regulation, interoception and dissociation

| Process | Description | Trauma pattern | Clinical response |
|---|---|---|---|
| Reappraisal | Changing meaning | Often impaired under high arousal | Introduce after stabilisation |
| Suppression | Inhibiting expression | Common but costly | Broaden repertoire |
| Interoception | Sensing internal state | Hyper- or hypo-awareness | Graded exposure to sensation |
| Depersonalisation | Detachment from self | Common in dissociation | Grounding, assessment |
| Derealisation | Unreality of surroundings | Common in dissociation | Safety, orientation |
| State dependence | Access varies by state | Inconsistent presentation | Continuity of care |

## Composite case study

A patient describes feeling "outside my body" during arguments and being unable to remember what she said. Assessment identifies depersonalisation and state-dependent memory. The plan includes grounding skills, reducing conflict triggers, and trauma-focused therapy with attention to dissociative barriers. Medication is reviewed for any contribution.

## Review and discussion questions

1. Why can suppression increase distress?
2. What are the limits of reappraisal as a trauma intervention?
3. Why is interoceptive accuracy not a straightforward marker of trauma?
4. How would you distinguish depersonalisation from psychosis?
5. What are the risks of using dissociation as an explanation for all inconsistency?
6. How should cultural meaning be incorporated into assessment of dissociation?

## Research assignments

- Design a study of interoceptive accuracy in PTSD that controls for anxiety and medication.
- Critically appraise one measure of dissociation, noting reliability and validity.
- Write a clinical protocol for responding to dissociation during trauma-focused therapy.

## Chapter summary

Emotion regulation, interoception and dissociation are interrelated processes that are frequently disrupted by trauma. Regulation includes appraisal, attention, acceptance and behaviour; interoception involves sensing and interpreting internal signals; dissociation involves disruptions of awareness, memory and identity. Assessment should be specific, culturally informed and medically alert. Treatment should be staged, with attention to stabilisation before processing.

## References

[BIBLIOGRAPHY]
