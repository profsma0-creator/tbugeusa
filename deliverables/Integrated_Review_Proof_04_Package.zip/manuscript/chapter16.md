# Chapter 16

## Systemic and Structural Trauma

**Central question.** How do collective, historical and structural harms affect individuals, and how should neurobiology engage with them?

### Learning objectives

- distinguish individual, collective and structural trauma;
- describe historical trauma and its contested evidence base;
- explain how discrimination and poverty affect stress physiology;
- evaluate the concept of trauma-informed organisations;
- identify the limits of neurobiological explanation for social harms.

## Introduction

Most trauma research studies individuals. But much trauma is collective: war, genocide, displacement, apartheid, colonialism, mass incarceration, natural disaster. And much harm is structural: it operates through laws, institutions, economies and norms rather than through a single perpetrator.

This chapter examines these levels. It asks what neurobiology can contribute to understanding collective and structural harm, and what it cannot. It argues that biological language can illuminate mechanisms—how discrimination gets under the skin—but that it can also individualise and depoliticise problems that require social change.

> **A note on terminology.** Historical trauma refers to cumulative emotional and psychological wounding across generations resulting from massive group trauma. Structural trauma refers to harm embedded in institutions and social arrangements. Collective trauma refers to shared psychological effects of a traumatic event on a group. The terms overlap and are used inconsistently in the literature.

## 16.1 Collective trauma

Collective trauma occurs when a group experiences an event that shatters shared assumptions and identities. It affects individuals, but it also affects the group's narratives, rituals, institutions and sense of safety.

Research on collective trauma draws on sociology, anthropology and history as well as psychology. It examines how communities remember, commemorate and transmit experiences, and how they rebuild.

Neurobiological methods are poorly suited to studying collective trauma directly. They can study individuals within affected groups, but they cannot capture the group-level processes that shape meaning and recovery.

## 16.2 Historical trauma

The concept of historical trauma was developed in relation to Indigenous communities in North America, particularly the legacy of boarding schools and forced assimilation. It proposes that massive group trauma has effects that persist across generations.

Empirical evidence is mixed. Studies report elevated rates of mental health problems, substance use and suicide in some Indigenous communities, but attributing these to historical trauma specifically is difficult because contemporary disadvantage, discrimination and ongoing colonialism are also powerful determinants.

The concept has political and clinical value: it acknowledges that harms are not only individual and not only past. It also risks overextension, and it should be used carefully rather than as a catch-all explanation.

## 16.3 Discrimination and stress physiology

Experiences of discrimination are associated with elevated stress hormones, blood pressure, inflammation and poor mental health. These associations are found across many groups and are not explained away by socioeconomic status.

Discrimination can be acute (a specific incident) or chronic (ongoing exposure to bias and exclusion). Chronic discrimination is a stressor that is unpredictable, uncontrollable and identity-relevant, which makes it particularly potent.

Biological measures can document the physiological cost of discrimination. They cannot, by themselves, prove causation, and they should not be used to individualise a structural problem. Their value is in showing that social experience has biological consequences—an argument against the idea that discrimination is "just" a perception.

## 16.4 Poverty and deprivation

Poverty exposes people to multiple stressors: food insecurity, housing instability, unsafe environments, limited access to health care and chronic uncertainty. These stressors affect stress physiology, cognitive bandwidth and mental health.

The relationship between poverty and trauma is bidirectional. Poverty increases exposure to traumatic events and reduces access to resources for recovery; trauma can also lead to loss of income, housing and social support.

Neurobiological research on poverty has documented associations with cortical development, language exposure and stress physiology. These findings should be interpreted carefully: they describe population patterns, not individual potential, and they can be used to justify deficit narratives if misapplied.

The argument that early socioeconomic adversity becomes biologically embedded is developed by Shonkoff and Garner (2012).

## 16.5 War and displacement

War and displacement produce trauma through direct violence, loss, separation, deprivation and uncertainty. Refugees often experience multiple traumas before, during and after migration, including detention, exploitation and discrimination in host countries.

Post-migration stressors—uncertain legal status, poverty, isolation, discrimination, difficulty accessing services—predict mental health outcomes alongside pre-migration trauma. This is an important corrective to the assumption that trauma is located only in the past.

Interventions should address both trauma and post-migration conditions. Clinical services that ignore housing, legal status and social support are unlikely to be sufficient.

## 16.6 Structural violence

Structural violence refers to harm that results from social arrangements rather than from identifiable individuals. It includes inadequate housing, unsafe work, pollution, food insecurity and unequal access to care.

Structural violence is often invisible in clinical settings because it does not present as a discrete event. A patient may present with chronic stress, depression or physical illness without reporting a "trauma" in the conventional sense.

Clinical practice can respond by asking about social conditions, connecting patients to resources and advocating for change. This is not a distraction from neurobiology; it is an application of the understanding that stress physiology is shaped by environment.

## 16.7 Trauma-informed organisations

Trauma-informed care is an organisational approach that recognises the prevalence of trauma, understands its effects, avoids re-traumatisation and supports recovery. It involves changes in policy, environment, language and staff training.

Evidence for trauma-informed organisational interventions is limited but growing. Studies report improvements in staff knowledge, patient experience and some clinical outcomes. The concept has been criticised for becoming a slogan without substantive change.

Genuine trauma-informed practice requires attention to power, safety, choice and transparency. It is not simply a training course; it is a change in how organisations operate.

## 16.8 Community resilience

Community resilience refers to the capacity of a community to withstand and recover from adversity. It involves social networks, shared identity, local leadership, infrastructure and access to resources.

Community-based interventions can be effective because they work with existing structures and reach people who do not access clinical services. They can also be more acceptable and sustainable than externally imposed programmes.

Research should be community-led where possible, with attention to consent, benefit-sharing and cultural appropriateness.

## 16.9 Measurement and attribution

Measuring the effects of collective and structural trauma is difficult. Exposure is often ongoing, comparison groups are hard to define, and outcomes are shaped by many factors.

Attribution requires designs that can separate the effects of a specific historical event from ongoing disadvantage. This is rarely possible with observational data, and researchers should be explicit about the limits of their claims.

Qualitative and participatory methods can complement quantitative approaches by capturing meaning, process and lived experience.

## 16.10 Responsibility of the field

The neurobiology of trauma has a responsibility to engage with social context. Biological explanations can be used to depoliticise suffering—to say that the problem is in the brain rather than in the conditions that produced it.

This does not mean that biology is irrelevant. It means that biological findings should be situated within social and political analysis, and that researchers should consider how their work might be used.

A responsible field acknowledges uncertainty, avoids biological determinism and supports interventions at multiple levels: individual, family, community and policy.

## Synthesis

Table 16.1 summarises levels of trauma and their implications.

Table 16.1. Levels of trauma

| Level | Examples | Neurobiological engagement | Limits |
|---|---|---|---|
| Individual | Assault, accident | Well-developed | Ignores context |
| Collective | War, disaster | Individual measures within groups | Cannot capture group process |
| Historical | Genocide, colonisation | Intergenerational studies | Attribution difficult |
| Structural | Poverty, discrimination | Stress physiology | Risks individualising |

## Composite case study

A refugee patient presents with insomnia and intrusive memories. Assessment identifies pre-migration violence but also post-migration stressors: uncertain status, crowded housing and discrimination. The plan combines trauma-focused therapy with practical support and advocacy. The clinician documents how social conditions affect symptoms without reducing the patient's experience to a social problem.

## Review and discussion questions

1. What is the difference between collective and structural trauma?
2. What are the strengths and limits of the historical trauma concept?
3. How can biological measures document the effects of discrimination without individualising them?
4. Why do post-migration stressors matter for refugee mental health?
5. What would genuine trauma-informed organisational change require?
6. How should researchers handle attribution when studying structural harms?

## Research assignments

- Design a study of discrimination and stress physiology that includes structural measures.
- Critically appraise the evidence for trauma-informed organisational interventions.
- Write a community consultation plan for research in a conflict-affected setting.

## Chapter summary

Trauma occurs at individual, collective, historical and structural levels. Neurobiology can document how social harms affect bodies, but it cannot capture group processes or substitute for social analysis. Discrimination, poverty, war and displacement affect stress physiology and mental health, and post-migration conditions matter as much as past events. The field should engage with social context, avoid biological determinism and support interventions at multiple levels.

## References

[BIBLIOGRAPHY]
