# Chapter 17

## Assessment and Differential Diagnosis

**Central question.** How should trauma-related conditions be assessed, and how can clinicians avoid the common errors of over- and under-diagnosis?

### Learning objectives

- describe the components of a trauma-informed assessment;
- distinguish PTSD from common differential diagnoses;
- explain the role of standardised instruments;
- recognise the effects of culture, language and context on assessment;
- identify when medical investigation is indicated.

## Introduction

Assessment is the foundation of good practice. It determines whether treatment is offered, which treatment, and whether the person is safe. It is also where many errors occur: trauma may be missed because it is not asked about, over-diagnosed because symptoms are attributed to trauma without considering alternatives, or misattributed to a medical condition that is not investigated.

This chapter sets out a structured approach. It covers history, symptom assessment, differential diagnosis, instruments, cultural considerations and medical screening. It emphasises that assessment is not a single event but a process that continues through treatment.

> **A note on asking.** Many people do not volunteer trauma histories. They may not recognise what happened as trauma, may fear consequences, or may have been discouraged from speaking. Asking directly, privately and without pressure increases disclosure. The question should be followed by a response that is respectful and practical, not by immediate interrogation.

## 17.1 Engagement and safety

Assessment begins with engagement. The person needs to know who you are, what you will do with the information, and what choices they have. Confidentiality and its limits should be explained.

Physical and emotional safety should be considered. Is the setting private? Is the person at risk at home? Are there immediate medical needs? These questions come before symptom inventories.

Assessment should be paced. A person who is highly dissociated or intoxicated may not be able to provide a reliable history, and the assessment should be resumed later rather than forced.

## 17.2 Trauma history

The trauma history should establish what happened, when, for how long, who was involved and what the consequences were. It should include childhood adversity, adult trauma, recent events and ongoing threats.

Questions should be specific enough to elicit information without being leading. Asking "have you ever been physically hurt by someone close to you" is more useful than asking "do you have trauma".

The history should also cover protective factors, supports and the person's own understanding of what happened. This informs formulation and engagement.

## 17.3 Symptom assessment

Core PTSD symptoms include intrusive memories, avoidance, negative alterations in cognition and mood, and alterations in arousal and reactivity. The assessment should establish frequency, intensity, duration and functional impact.

It should also assess dissociation, complex PTSD features, depression, anxiety, substance use, psychosis, suicidal ideation and self-harm. Comorbidity is the rule rather than the exception.

Symptoms should be linked to functioning: work, relationships, sleep, self-care and safety. A symptom count without functional context is of limited use.

Most adults report at least one traumatic event, but only a minority develop PTSD (Kessler et al., 1995).

## 17.4 Standardised instruments

Standardised instruments improve reliability and support monitoring. Commonly used measures include the PTSD Checklist for DSM-5, the Clinician-Administered PTSD Scale, the Impact of Event Scale-Revised and the Dissociative Experiences Scale.

Instruments are screening or severity measures, not diagnoses. They depend on the population, the language and the method of administration. Cut-off scores should be interpreted with knowledge of local validation.

Self-report instruments can be completed privately, which may increase disclosure. They can also be affected by literacy, language and cultural interpretation of items.

## 17.5 Differential diagnosis

Several conditions can mimic or co-occur with PTSD. Major depression shares low mood, sleep disturbance and concentration difficulties. Generalised anxiety shares hyperarousal and worry. Panic disorder shares autonomic arousal. Psychosis can involve intrusive experiences that resemble flashbacks. Traumatic brain injury can produce cognitive and emotional changes.

Medical conditions should be considered: thyroid disease, anaemia, sleep apnoea, chronic pain, medication effects and substance withdrawal. These can produce symptoms that overlap with trauma.

The goal is not to exclude trauma but to avoid attributing everything to it. A person can have PTSD and hypothyroidism, and treating one does not treat the other.

Diagnosis rests on clinical interview against established criteria rather than on screening scores alone (Yehuda et al., 2015).

## 17.6 Dissociation and complex presentations

Dissociation should be assessed specifically, including depersonalisation, derealisation, amnesia and identity confusion. Severe dissociation may require a modified treatment approach.

Complex PTSD, as defined in ICD-11, includes the core PTSD symptoms plus disturbances in self-organisation: affect dysregulation, negative self-concept and difficulties in relationships. Assessment should establish whether these features are present and how they affect functioning.

Personality disorder diagnoses should be made cautiously in the context of trauma, because many features overlap and because labelling can be stigmatising. Where a diagnosis is made, it should inform treatment rather than replace formulation.

The dissociative subtype and its assessment are reviewed by Lanius et al. (2010).

## 17.7 Cultural and linguistic considerations

Culture shapes how distress is expressed, what is considered traumatic, who is consulted and what help is acceptable. Somatic idioms, spiritual explanations and family-based coping are common and should be respected.

Language is central. Assessment in a second language may obscure nuance, and interpreters should be trained and briefed. Family members should not interpret for sensitive assessments.

Instruments developed in one culture may not be valid in another. Local validation and qualitative input are important.

## 17.8 Medical screening

Medical screening should be guided by the history and presentation. Indicated investigations might include thyroid function, full blood count, glucose, vitamin levels and, where relevant, toxicology.

Red flags—focal neurological signs, sudden cognitive decline, severe headache, seizures, unexplained weight loss—require urgent medical assessment. These should not be attributed to trauma without investigation.

The interface between trauma and medicine is often poorly managed. Coordinated care between mental health and primary care improves outcomes.

## 17.9 Risk assessment

Risk assessment should cover suicide, self-harm, harm to others, safeguarding and immediate danger. It should be documented and followed by a plan.

Asking about suicide does not increase risk. It provides an opportunity to intervene. Assessment should include intent, plan, means, protective factors and access to support.

Risk is not a static property of a person; it changes with circumstances. Assessment should be repeated at transitions and during crises.

## 17.10 Formulation and feedback

Formulation integrates the history, symptoms, context and strengths into an explanatory account that guides treatment. It should be shared with the person, checked for accuracy and revised as new information emerges.

Feedback improves engagement and outcomes. It also respects the person's expertise about their own life.

Formulation is not a diagnosis. It is a working model that can accommodate complexity, uncertainty and change.

## Synthesis

Table 17.1 summarises assessment components.

Table 17.1. Components of trauma-informed assessment

| Component | Purpose | Common errors |
|---|---|---|
| Engagement | Safety, consent | Rushing to symptoms |
| Trauma history | Identify exposure | Not asking directly |
| Symptom assessment | Severity, function | Counting symptoms only |
| Instruments | Reliability, monitoring | Treating scores as diagnosis |
| Differential diagnosis | Avoid misattribution | Attributing all to trauma |
| Risk assessment | Safety planning | Avoiding the question |
| Formulation | Integrated explanation | Not sharing with the person |

## Composite case study

A patient presents with insomnia, irritability and intrusive images. Assessment identifies a traumatic event, but also untreated sleep apnoea and heavy alcohol use. The formulation integrates these factors. Treatment addresses sleep, alcohol and trauma in a sequenced plan, with medical follow-up. The clinician does not assume that trauma explains everything.

## Review and discussion questions

1. How would you ask about trauma in a way that increases disclosure?
2. Why are screening instruments not diagnostic?
3. Which medical conditions should be considered in the differential diagnosis of PTSD?
4. How should interpreters be used in trauma assessment?
5. What are the risks of diagnosing personality disorder in trauma survivors?
6. Why should formulation be shared with the person?

## Research assignments

- Compare two PTSD instruments, noting validation evidence and cultural limitations.
- Design an assessment protocol for a refugee clinic.
- Write a risk assessment template that is trauma-informed and legally defensible.

## Chapter summary

Trauma-informed assessment integrates engagement, trauma history, symptoms, differential diagnosis, risk and formulation. Standardised instruments support but do not replace clinical judgement. Culture, language and medical conditions shape presentation and require attention. A good assessment avoids both under-recognition and over-attribution, and it results in a shared formulation that guides treatment and can be revised.

## References

[BIBLIOGRAPHY]
