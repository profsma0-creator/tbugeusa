# Glossary

Editorial reconstruction — not final. All 187 original headwords are retained with corrected capitalisation and term-specific definitions. Source codes identify resources checked for the core concept, sometimes only through an abstract or search excerpt; they do not certify every qualification. 59 entries have core-concept source checks; 128 have working definitions awaiting term-specific source checks. Uncoded entries are provisional. All entries still require reconciliation with chapter usage and a second specialist proofreading pass. This glossary is not a diagnostic manual or a clinical protocol.

**Acetylcholine.** A neurotransmitter acting at nicotinic and muscarinic receptors; it mediates neuromuscular transmission and has autonomic and central nervous system functions. (G01)

**Acquisition.** The initial development of a learned response or association during training. In conditioning, acquisition is distinguished from later extinction and retrieval.

**ACTH.** Adrenocorticotrophic hormone: an anterior pituitary hormone that stimulates glucocorticoid secretion by the adrenal cortex as part of the hypothalamic–pituitary–adrenal axis. (G09)

**Action potential.** A brief, regenerative change in membrane potential that propagates an electrical signal along an excitable cell membrane. (G01)

**Adaptation.** An adjustment in physiological function, behaviour or cognition in relation to environmental demands. An adjustment useful during danger may become costly in a safer context. (G05)

**Adverse effect.** An unwanted harmful effect associated with an intervention. Temporal association alone does not establish that the intervention caused it.

**Affect dysregulation.** Difficulty modulating the intensity, duration or expression of emotional states in ways suited to the situation. (G05)

**Allele.** An alternative version of a DNA sequence at a particular genomic location. (G02)

**Allostasis.** Maintenance of physiological stability through changes in regulatory activity in response to anticipated or actual demands. (G09)

**Allostatic load.** The cumulative physiological burden associated with repeated or poorly regulated adaptive responses; its measurement requires an explicitly specified set of indicators. (G09)

**Artificial intelligence.** Computational systems designed to perform tasks involving capacities such as inference, learning or decision-making. The term does not imply consciousness or clinical competence.

**Astrocyte.** A central nervous system glial cell that supports neuronal function and contributes to the maintenance of the blood–brain barrier. (G01)

**Attachment.** An enduring emotional bond through which a person seeks proximity, comfort or security from an attachment figure, particularly a caregiver in early life. (G05)

**Attachment disruption.** Interruption or destabilisation of a relationship that ordinarily provides security and emotional support. It is not, by itself, a diagnosis of an attachment disorder. (G05)

**Avoidance.** Attempts to evade distressing internal experiences or external reminders. In PTSD, these may include trauma-related thoughts, feelings, places or activities. (G06)

**Axon.** A neuronal process that carries signals towards other neurons, muscle cells or glands. (G01)

**Bilateral stimulation.** Alternating stimulation of the two sides of the body or sensory field, such as back-and-forth eye movements, sounds or taps used within EMDR.

**Biomarker.** A measured characteristic indicating a biological process, a disease process or a response to an exposure or intervention. Its interpretation depends on the intended context of use. (G10)

**Blood–brain barrier.** A selective physiological interface between the circulation and central nervous system that restricts the passage of substances into brain tissue. (G01)

**Blood–brain communication.** Exchange of signals between the circulation and brain through transport, vascular and other signalling mechanisms. Communication does not require unrestricted passage across the blood–brain barrier.

**BOLD signal.** Blood-oxygen-level-dependent MRI contrast, influenced by changes in deoxyhaemoglobin and the haemodynamic response. It is an indirect measure of neural activity, not a recording of individual neurons firing.

**Brain–computer interface.** A system that uses recorded brain activity to control, communicate with or otherwise interact with an external device.

**C-reactive protein.** A circulating acute-phase protein used as a nonspecific indicator of inflammation. An elevated concentration does not identify a particular psychological cause.

**Calibration.** In measurement, comparison or adjustment against a reference standard. In probabilistic prediction, agreement between predicted probabilities and observed outcome frequencies.

**Causation.** A relationship in which changing one factor would change an outcome under specified conditions. An observed association alone is insufficient to establish causation.

**Chemokine.** A member of a family of signalling proteins that direct cell movement, including the migration of immune cells.

**Childhood adversity.** Potentially harmful experiences or circumstances during childhood, such as abuse, neglect or serious family disruption. Adversity is broader than any one diagnostic definition of traumatic exposure. (G05)

**Circadian rhythm.** An approximately 24-hour cycle in biological activity, coordinated by internal timing mechanisms and influenced by environmental cues such as light.

**Circuit.** An interconnected set of neurons or brain regions participating in information processing. A circuit need not correspond to a single psychological function.

**Classifier.** A computational rule or model that assigns observations to categories, sometimes with estimated probabilities.

**Clinical utility.** The usefulness of a test or intervention for improving decisions or outcomes in an intended clinical setting, taking account of potential harms and practical consequences.

**Co-regulation.** Support through another person's responsive interaction that helps an individual modulate emotional or physiological states.

**Cognitive change.** An alteration in attention, memory, interpretation, reasoning or beliefs. In treatment research, the particular cognitive process and its measurement must be specified.

**Comorbidity.** The presence of two or more disorders or health conditions in the same person. It does not establish that one condition caused another.

**Complex trauma.** Repeated or multiple traumatic experiences, often interpersonal, together with their potentially wide-ranging effects. This exposure-related concept is not synonymous with a diagnosis of complex PTSD.

**Conditioned stimulus.** A stimulus that acquires the capacity to elicit a learned response through its predictive relationship with another event.

**Conditioning.** Learning through relationships between events, or between actions and their consequences. Classical and operant conditioning describe different arrangements.

**Confounding.** Distortion of an estimated exposure–outcome relationship by another variable associated with both the exposure and outcome, rather than lying on the causal pathway. (G03)

**Connectivity.** Connections or statistical relationships between neural elements. Structural, functional and effective connectivity refer to anatomical pathways, covariation and modelled directional influence, respectively.

**Connectome.** A representation of neural connections at a specified spatial scale, from individual cells to larger brain regions.

**Consolidation.** Processes through which newly acquired information becomes more stable over time. Cellular and systems consolidation concern different levels of explanation.

**Construct.** A theoretical attribute or process, such as perceived threat, defined for explanation or measurement rather than directly observed as a single physical object.

**Correlation.** Statistical covariation between variables. Its magnitude and interpretation depend on the measure used; correlation does not, by itself, establish causation.

**Corticotropin-releasing hormone.** A peptide involved in stress regulation; hypothalamic release stimulates pituitary ACTH secretion. Corticotropin-releasing factor is a commonly used alternative name. (G09)

**Cortisol.** A glucocorticoid hormone produced by the adrenal cortex, involved in metabolic, immune and stress regulation; concentrations vary with circadian timing and other influences. (G09)

**Cumulative risk.** The combined burden of multiple risk exposures or conditions. A count of exposures does not necessarily capture their severity, timing or interaction.

**Cytokine.** A signalling protein that influences cell activity, particularly immune and inflammatory responses. Different cytokines have different, context-dependent functions.

**Dendrite.** A neuronal process that commonly receives synaptic input from other cells. (G01)

**Depersonalisation.** An experience of detachment from one's body, mental processes or sense of self. (G07)

**Depression.** A term used for depressed mood and for depressive disorders. A disorder requires a defined pattern of symptoms and clinical assessment, not sadness alone.

**Derealisation.** An experience in which the surrounding world feels unreal, distant, dreamlike or distorted. (G07)

**Developmental cascade.** A sequence in which change in one area of development influences other areas over time; the direction and mechanisms require empirical investigation.

**Developmental timing.** The age or developmental stage at which an experience or biological process occurs, considered in relation to its possible effects.

**Diagnostic marker.** A biomarker used to detect or confirm a condition, or identify a subtype. An association with a disorder does not by itself establish diagnostic performance.

**Differential diagnosis.** The clinical process of distinguishing between conditions that could explain a person's presentation, including medical, substance-related and psychological alternatives.

**Diffusion imaging.** MRI methods sensitive to the movement of water molecules in tissue. Diffusion measures can inform models of tissue organisation but do not directly count axons.

**Digital phenotype.** A measurable pattern of behaviour or functioning derived from digital devices, such as movement or interaction data. Its meaning requires validation and attention to privacy.

**Discrimination.** In learning, responding differently to distinguishable stimuli. In prediction, a model's ability to distinguish outcome groups. In social contexts, unequal or unfair treatment.

**Dissociation.** Disruption in the usual integration of awareness, memory, identity or perception. Depersonalisation and derealisation are particular dissociative experiences. (G05; G07)

**DNA methylation.** Addition of methyl groups to DNA, an epigenetic modification that can influence gene regulation without changing the underlying DNA sequence. (G11)

**Dopamine.** A monoamine neurotransmitter involved in functions including movement, learning, motivation and reward processing. It is not a simple measure of pleasure.

**EEG.** Electroencephalography: recording of electrical potential differences, usually at the scalp, reflecting the combined activity of neuronal populations.

**Effect size.** A quantitative measure of the magnitude of a difference, association or other effect. It should be interpreted with its uncertainty and the study's design.

**Emotion regulation.** Processes that influence which emotions arise, their intensity or duration, and how they are experienced or expressed. (G05)

**Encoding.** Processes through which information is initially represented in a form that can contribute to subsequent memory.

**Endocannabinoid.** A lipid-derived signalling molecule produced within the body that acts at cannabinoid receptors; examples include anandamide and 2-arachidonoylglycerol.

**Endophenotype.** A measurable, partly heritable characteristic investigated as an intermediate link between genetic variation and a disorder. A proposed endophenotype requires evidence, not merely an association.

**Epigenetics.** Study of modifications to DNA and associated proteins that influence gene activity without altering the underlying DNA sequence. Not every modification is transmitted between generations. (G11)

**Executive control.** Processes that support goal-directed behaviour, including maintaining goals, inhibiting competing responses and adjusting actions.

**Explainability.** The extent to which the basis or operation of a computational prediction can be described intelligibly. An explanation does not establish that a prediction is accurate or causal.

**Extinction.** A reduction in a learned response when the previously predictive relationship or reinforcement no longer occurs. It need not erase the original learning.

**Extinction learning.** Learning associated with extinction, such as learning that a previously threatening cue no longer predicts harm in a particular context.

**Feature.** An input variable or representation supplied to a computational model, such as a symptom score or an imaging-derived measurement.

**Flexibility.** The capacity to adjust behaviour, attention or regulatory strategies when goals or circumstances change. The relevant domain must be specified.

**fMRI.** Functional magnetic resonance imaging: MRI methods used to study brain function, commonly through BOLD contrast rather than direct measurement of neuronal firing.

**Functional impairment.** Interference with activities or roles such as work, education, relationships or self-care. It is distinct from the mere presence of a symptom. (G06)

**GABA.** Gamma-aminobutyric acid: a major inhibitory neurotransmitter in the mature central nervous system. Its effects depend on receptor and cellular conditions.

**Gene.** A DNA sequence that contributes to a functional product, such as an RNA molecule or a protein. Gene activity is regulated rather than fixed at a constant level.

**Gene–environment interplay.** The joint contribution of genetic variation and environmental conditions to development or outcomes. The term can include interaction and gene–environment correlation.

**Generalisation.** Extension of a learned response to new stimuli or contexts. In machine learning, performance on observations not used to fit the model.

**Genotype.** The genetic variants present at a specified genomic location or set of locations; the term may also refer more broadly to genetic constitution.

**Glutamate.** An amino acid that serves as the principal excitatory neurotransmitter in the central nervous system and participates in synaptic plasticity.

**Grey matter.** Nervous tissue containing neuronal cell bodies, dendrites, synapses and glia, with fewer myelinated axons than white matter. (G01)

**Heritability.** A population-specific estimate of the proportion of variation in a trait attributable to genetic differences under specified conditions. It is not an individual's percentage of genetic determination.

**Heterogeneity.** Variation within a population or body of evidence. Clinical, biological and methodological heterogeneity are different forms and should not be conflated.

**Histone.** A DNA-associated protein involved in chromatin organisation; histone modifications can influence the accessibility and regulation of genetic information.

**Homeostasis.** Regulation of internal physiological conditions within ranges compatible with functioning, through interacting feedback and control processes. (G09)

**Hyperarousal.** Heightened arousal or reactivity, such as exaggerated startle, vigilance or sleep disturbance. It is not specific to PTSD. (G06)

**Immune regulation.** Processes that initiate, coordinate, limit or resolve immune responses. Regulation is not equivalent to increasing immune activity.

**Immunity.** The body's capacity to recognise and respond to harmful agents through innate and adaptive defence mechanisms.

**Implementation.** The deliberate introduction and sustained use of an intervention or practice in a real-world setting, including attention to feasibility and context.

**Inflammation.** A coordinated tissue and immune response to injury or harmful stimuli. Acute and persistent inflammation differ in duration and potential consequences.

**Insula.** A region of cerebral cortex within the lateral sulcus, involved in functions including interoceptive, sensory and affective processing.

**Interleukin.** A cytokine designated within the interleukin family. Interleukins influence immune and other cellular activities and do not all have the same inflammatory effects.

**Interoception.** Sensing and processing signals from within the body, including signals related to visceral and physiological states.

**Intrusion.** An involuntary entry of distressing memories, images or related experiences into awareness; trauma-related intrusions can include nightmares and flashbacks. (G06)

**Ion channel.** A membrane protein forming a pathway through which selected ions can move. Channel opening and selectivity shape cellular electrical signalling. (G01)

**Machine learning.** Computational methods that fit patterns or decision rules from data, rather than requiring every rule to be explicitly specified in advance.

**Maturation.** Developmental change through which biological or psychological systems acquire more developed organisation or capacities; it occurs in interaction with experience.

**Mechanism.** A process or organised set of processes proposed to explain how an effect occurs. A correlation or group difference is not, by itself, a mechanism.

**Mediator.** A variable proposed to transmit part of the effect of an exposure or intervention on an outcome. Statistical mediation alone does not establish a causal mechanism.

**MEG.** Magnetoencephalography: recording of very small magnetic fields generated by electrical activity in neuronal populations.

**Membrane potential.** The electrical potential difference across a cell membrane, arising from ionic distributions and membrane properties. (G01)

**Memory system.** A set of processes and neural substrates supporting a form of memory, such as episodic or procedural memory. The classification depends on the theoretical framework.

**Meta-analysis.** A statistical synthesis of results from multiple studies addressing a defined question. Its conclusions depend on study quality, comparability and the synthesis model.

**Metacognition.** Monitoring and regulation of one's own cognitive processes, including judgements about memory or confidence in a decision.

**Microglia.** Resident immune cells of the central nervous system, involved in surveillance and responses to tissue disturbance. (G01)

**Migration.** Movement of cells from one location to another. In neurodevelopment, neuronal migration contributes to the arrangement of cells in developing tissue.

**Mitochondrion.** A cellular organelle involved in energy metabolism and other functions, including calcium handling and regulation of cell survival.

**Moderator.** A variable associated with differences in the magnitude or direction of a relationship across its levels. Moderation describes a conditional relationship, not necessarily its mechanism.

**MRI.** Magnetic resonance imaging: production of images from magnetic resonance signals, using magnetic fields and radiofrequency pulses. Different sequences provide different tissue contrasts.

**Myelin.** A lipid-rich sheath around many axons that supports rapid electrical conduction; it is produced by oligodendrocytes in the CNS and Schwann cells in the peripheral nervous system. (G01)

**Myelination.** Formation and development of myelin sheaths around axons. (G01)

**Negative cognition.** A negatively valenced thought, interpretation or belief, such as an expectation of danger or self-blame. The term requires a specified context and measure. (G06)

**Negative self-concept.** A pattern of unfavourable beliefs or feelings about oneself, such as worthlessness, shame or perceived failure. (G05)

**Neuroanatomy.** Study of the structure and organisation of the nervous system.

**Neurodevelopment.** Development of the nervous system through interacting cellular, circuit-level and experiential processes across the lifespan.

**Neurogenesis.** Production of new neurons from precursor cells. Its extent and functional significance depend on species, brain region and developmental stage.

**Neuroimaging artefact.** An image feature or signal distortion arising from acquisition, movement, physiology or processing rather than the phenomenon being interpreted.

**Neuromodulation.** Alteration of neuronal or circuit activity by chemical signalling or an intervention such as electrical or magnetic stimulation; the intended meaning depends on context.

**Neuron.** A nervous system cell specialised for receiving, integrating and transmitting signals to other cells. (G01)

**Neuropeptide.** A peptide used in neural signalling that can influence the activity of neurons and other target cells. (G01)

**Neuroscience.** The scientific study of the nervous system and its relationships with behaviour, cognition, emotion, bodily regulation, development and disease.

**Neurotransmission.** Communication in which a neuron influences a target cell through chemical transmitter release or direct electrical coupling. (G01)

**Noradrenaline.** A catecholamine, also called norepinephrine, acting as a neurotransmitter and hormone in arousal, autonomic and stress-related regulation. (G09)

**Nucleus.** In neuroanatomy, a localised group of neuronal cell bodies in the central nervous system. In cell biology, the membrane-bound compartment containing most cellular DNA. (G01)

**Oligodendrocyte.** A central nervous system glial cell that forms myelin around axons. (G01)

**Operational definition.** The explicit procedures used to identify, manipulate or measure a construct in a particular study.

**Opioid.** A substance acting at opioid receptors, including endogenous peptides and medicines. Effects depend on the substance, receptor and dose.

**Overfitting.** Fitting patterns specific to training data so closely that performance is poor on new data from the intended application. (G04)

**Oxidative stress.** A disturbance in the balance between oxidant production and antioxidant regulation that can disrupt signalling or damage cellular components.

**Parasympathetic system.** A division of the autonomic nervous system involved in functions such as cardiac slowing and digestive regulation. Its activity is not a direct measure of psychological safety.

**PET.** Positron emission tomography: imaging of the distribution of a positron-emitting tracer to investigate processes such as metabolism or receptor binding.

**Pharmacotherapy.** Treatment using medicines, selected and monitored according to the condition, evidence, potential harms and individual circumstances.

**Phenotype.** An observable or measurable characteristic arising through genetic and environmental influences, including biological or behavioural traits.

**Plasticity.** The capacity of neural structure or function to change through development, experience, learning, injury or intervention. Change is not necessarily beneficial.

**Polygenic score.** A numerical summary combining information across multiple genetic variants, usually weighted by estimated associations with a trait. It is not a deterministic prediction.

**Potentiation.** An increase in the strength or effectiveness of a response. Synaptic potentiation refers specifically to increased synaptic efficacy.

**Precision neuroscience.** An approach seeking to characterise individual differences in nervous system function or organisation with sufficiently detailed and reliable measurements. It does not imply established individualised clinical prediction.

**Prediction error.** A discrepancy between an expected and an observed event or outcome, which can contribute to updating learned expectations.

**Predictive marker.** A biomarker used to identify the likelihood of a response to an exposure or intervention. It is distinct from a marker of the likely course of a condition without that intervention.

**Prognostic marker.** A biomarker used to estimate the likelihood of a future clinical event or disease course in people with a condition.

**Protective factor.** A characteristic or condition associated with a reduced likelihood or impact of an adverse outcome in a specified context. It does not guarantee protection.

**Protective relationship.** A relationship that provides safety, reliable support or other resources that may reduce the impact of adversity.

**Protein kinase.** An enzyme that transfers a phosphate group to a protein, thereby potentially altering its activity, interactions or location.

**Pruning.** Selective reduction or removal of neural connections or processes during development or plasticity. It is not interchangeable with indiscriminate neuronal loss.

**Psychoneuroimmunology.** Study of interactions among psychological processes, the nervous system and immune function.

**Psychotherapy.** A structured psychological treatment delivered through a therapeutic relationship to address distress, symptoms or functioning.

**PTSD.** Post-traumatic stress disorder: a disorder that can follow traumatic exposure, with symptoms involving intrusion, avoidance, changes in cognition or mood, and arousal or reactivity. Diagnosis requires the applicable clinical criteria, not a biomarker alone. (G06)

**Reappraisal.** Changing the interpretation of a situation in order to influence its emotional significance or effects.

**Receptor.** A molecular structure that recognises a signal, such as a neurotransmitter or hormone, and initiates or modifies a cellular response. (G01)

**Reconsolidation.** Processes through which a retrieved memory may become labile and subsequently restabilise. Retrieval does not invariably trigger reconsolidation or permit reliable memory erasure.

**Recovery.** Improvement or restoration of symptoms, functioning or well-being after adversity or illness. The relevant outcomes and time frame must be specified.

**Recovery trajectory.** A pattern of change in recovery-related outcomes over time, which can include improvement, fluctuation or persistent difficulties.

**Relational disturbance.** Difficulty forming, maintaining or feeling secure in relationships. This is a descriptive term, not an independent diagnosis. (G05)

**Reliability.** The consistency or precision of measurements under specified conditions. A reliable measure can still fail to measure the intended construct accurately.

**Renewal.** Return of an extinguished conditioned response when the cue is encountered in a context different from the extinction context.

**Resilience.** Dynamic maintenance or recovery of meaningful function despite adversity, supported by interacting personal, relational, biological and social conditions.

**Retrieval.** Access to or use of previously encoded information. Successful retrieval depends on cues, context and the state of the memory system.

**Salience.** The prominence or relevance of information for attention or behaviour, arising from its features, learned meaning or current goals.

**Sampling.** The selection of observations, people or other units from a target population or data source. The sampling procedure affects the scope of inference.

**Second messenger.** An intracellular signalling molecule generated or released in response to receptor activation that conveys or amplifies a signal within the cell. (G01)

**Self-regulation.** Processes through which a person modulates attention, emotion, behaviour or physiological arousal in relation to goals and circumstances. (G05)

**Sensitive period.** A developmental interval during which particular experiences have comparatively strong effects on a system. It does not imply that subsequent change is impossible.

**Sensitivity.** For a diagnostic test at a specified threshold, the proportion of people with the target condition who test positive. The relevant meaning differs in sensitivity analyses. (G03)

**Serotonin.** A monoamine neurotransmitter, also called 5-hydroxytryptamine, involved in multiple functions including mood, sleep and bodily regulation. Its role is not reducible to a simple happiness chemical.

**Social buffering.** Reduction of stress responses or their effects in the presence of supportive social relationships or interactions. Its occurrence depends on the context and relationship.

**Source localisation.** Estimation of the locations of neural generators from recorded signals, commonly EEG or MEG, using assumptions and an explicit source model.

**Specificity.** For a diagnostic test at a specified threshold, the proportion of people without the target condition who test negative. (G03)

**State dependence.** Variation in a process or response according to the individual's current state. In memory, retrieval may differ with the match between encoding and retrieval states.

**Stressor.** An event, condition or demand that challenges or threatens an organism's regulatory resources. Responses depend on characteristics of the event and the individual. (G09)

**Suppression.** An attempt to inhibit an expression, thought or response. Expressive suppression and attempts to suppress thoughts or memories are distinct processes.

**Sympathetic system.** A division of the autonomic nervous system involved in functions including cardiovascular and metabolic responses to demands. It is active in ordinary regulation as well as emergencies.

**Synapse.** A specialised junction through which a neuron communicates with another cell by chemical or electrical signalling. (G01)

**Synaptogenesis.** Formation of synaptic connections between neurons or between neurons and other target cells.

**Test set.** Data reserved for evaluating a fitted model after model selection, rather than for fitting or tuning it. Repeated use for decisions can compromise the independence of the evaluation. (G04)

**Tract.** A bundle of axons within the central nervous system, connecting neural regions. (G01)

**Training set.** Data used to fit a computational model's parameters or decision rules, distinct from data reserved for independent evaluation. (G04)

**Transcription.** In molecular biology, synthesis of an RNA molecule using DNA as a template. In qualitative research, production of a written record from speech or other recorded material.

**Translation.** In molecular biology, synthesis of a polypeptide according to an RNA sequence. In translational research, movement between research findings and practical applications; these are different meanings.

**Traumatic stress.** Psychological and biological responses following traumatic exposure. Such responses do not necessarily constitute PTSD; diagnostic definitions of exposure and disorder must be distinguished.

**Treatment mechanism.** A process through which a treatment produces change. Establishing a mechanism requires more than observing improvement or a pre–post biological difference.

**Unconditioned stimulus.** A stimulus that elicits a response without the specific prior conditioning under investigation.

**Vagus nerve.** The tenth cranial nerve, carrying sensory and motor fibres involved in communication between the brainstem and several thoracic and abdominal organs.

**Validation.** Evaluation of evidence for a measure's intended interpretation or a model's performance in a specified context. Internal model tuning and independent external validation are not interchangeable.

**Validity.** The extent to which evidence supports the intended interpretation and use of a measurement or inference. It is specific to the purpose and context, not an unrestricted property of a test. (G03)

**White matter.** Nervous tissue consisting predominantly of axonal pathways, many of them myelinated, together with glia and other supporting structures. (G01)

## Supporting sources

Source labels are local cross-references. Dates are left as n.d. where a publication date has not been confirmed; access was reviewed on 21 October 2026.

**G01.** OpenStax. (n.d.). Chapter 12: Key terms. Anatomy and Physiology. https://openstax.org/books/anatomy-and-physiology/pages/12-key-terms

Access and limits: Page chunks 1–2 read; foundational terminology. Corporate website attribution, not a claim that the textbook has no named authors. Neuronal processes, membrane signalling, neural tissue and glia. These short source definitions support the core concepts, not every explanatory qualification in the reconstruction.

**G02.** National Human Genome Research Institute. (n.d.). Talking glossary of genomic and genetic terms. https://www.genome.gov/genetics-glossary

Access and limits: Chunks 0, 4 and 5 read. Only allele assigned a checked definition in this pass. Allele. Other genetics entries remain uncoded pending checking of their exact definitions and qualifications.

**G03.** Centers for Disease Control and Prevention. (n.d.). Glossary. Principles of Epidemiology. https://archive.cdc.gov/www_cdc_gov/csels/dsepd/ss1978/glossary.html

Access and limits: Archived page chunks 0–1 read; search excerpts for sensitivity and specificity. Validity checked against the separate current CDC epidemiology glossary excerpt as well. Confounding, sensitivity, specificity and measurement validity. Advanced validity wording requires a further methodological source. Additional resource: https://www.cdc.gov/reproductive-health/glossary/index.html

**G04.** Google for Developers. (n.d.). Machine learning glossary. https://developers.google.com/machine-learning/glossary

Access and limits: Chunk 0 read; search excerpts for overfitting and test set. Training/test distinctions additionally checked against the Google course excerpt below. Overfitting and separation of training, validation and test data. Other computational terms are not marked checked. Additional resource: https://developers.google.com/machine-learning/crash-course/overfitting/dividing-datasets

**G05.** National Child Traumatic Stress Network. (n.d.). Effects. Complex trauma. https://www.nctsn.org/what-is-child-trauma/trauma-types/complex-trauma/effects

Access and limits: Both page chunks read. Child-focused explanatory resource, not a formal adult diagnostic glossary. Adaptation, attachment, emotional regulation, dissociation, negative self-concept and relational difficulties. Definitions are editorial syntheses; do not generalise the resource's child-focused associations into universal causal claims.

**G06.** National Institute of Mental Health. (n.d.). Post-traumatic stress disorder. https://www.nimh.nih.gov/health/publications/post-traumatic-stress-disorder-ptsd

Access and limits: Search excerpt containing symptom domains, duration and impairment read. Full page not read in this pass. PTSD symptom-domain overview, avoidance, intrusions, arousal, negative cognitions and functional interference. Glossary does not reproduce a complete diagnostic checklist or collapse DSM and ICD formulations.

**G07.** National Center for PTSD. (n.d.). Dissociative subtype of PTSD. U.S. Department of Veterans Affairs. https://www.ptsd.va.gov/professional/treat/essentials/dissociative_subtype.asp

Access and limits: Search excerpt defining depersonalisation and derealisation read; not a full literature review. Distinction between detachment from self and unreality of surroundings. No prevalence or neuroimaging results imported.

**G09.** Godoy, L. D., Rossignoli, M. T., Delfino-Pereira, P., Garcia-Cairasco, N., & de Lima Umeoka, E. H. (2018). A comprehensive overview on stress neurobiology: Basic concepts and clinical implications. Frontiers in Behavioral Neuroscience, 12, Article 127. https://doi.org/10.3389/fnbeh.2018.00127 https://www.frontiersin.org/journals/behavioral-neuroscience/articles/10.3389/fnbeh.2018.00127/full

Access and limits: Previously checked selectively for Chapter 1: chunks 0–1 and 48. Full bibliographic record remains in chapter01-verified-references.json. Stress-regulatory framework and HPA/SAM terminology. Indicator selection for allostatic load still requires a dedicated measurement source; do not label the glossary a comprehensive verification of this topic.

**G10.** U.S. Food and Drug Administration. (n.d.). About biomarkers and qualification. https://www.fda.gov/drugs/biomarker-qualification-program/about-biomarkers-and-qualification

Access and limits: Page chunk 0 previously read for Chapter 1. Biomarker definition and context of use. No claim that a PTSD biomarker has been qualified.

**G11.** National Human Genome Research Institute. (n.d.). Epigenomics fact sheet. https://www.genome.gov/about-genomics/fact-sheets/Epigenomics-Fact-Sheet

Access and limits: Search excerpt concerning DNA/protein modification, gene expression and DNA methylation read. Core epigenetic and methylation concepts. No claim of demonstrated human transgenerational transmission of trauma.
